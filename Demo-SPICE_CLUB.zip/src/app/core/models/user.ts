export class User {
  
  access_token:any;
    id: any;  
    token:any;
    user:any;
    expires_at:any;
    message: any;  
    token_type:any;
  }
  